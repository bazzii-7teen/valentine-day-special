import { useEffect, useState, useRef } from 'react'
import './App.css'
import { Heart, Sparkles, Music, Gift, Star, ArrowDown } from 'lucide-react'
import { Button } from '@/components/ui/button'

// Floating hearts component
function FloatingHearts() {
  const [hearts, setHearts] = useState<Array<{ id: number; left: number; delay: number; size: number }>>([])

  useEffect(() => {
    const newHearts = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 8,
      size: Math.random() * 20 + 10,
    }))
    setHearts(newHearts)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute animate-float-up"
          style={{
            left: `${heart.left}%`,
            animationDelay: `${heart.delay}s`,
            animationDuration: `${8 + Math.random() * 4}s`,
          }}
        >
          <Heart
            size={heart.size}
            className="text-rose-300/40 fill-rose-300/40"
          />
        </div>
      ))}
    </div>
  )
}

// Hero Section
function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const scrollToLetter = () => {
    document.getElementById('love-letter')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/hero-bg.jpg)' }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-rose-900/30 via-rose-800/20 to-rose-900/40" />
      
      {/* Content */}
      <div className={`relative z-10 text-center px-4 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="flex justify-center mb-6">
          <Sparkles className="w-8 h-8 text-yellow-300 animate-pulse" />
        </div>
        
        <p className="font-script text-2xl md:text-3xl text-rose-100 mb-4 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          To My Beautiful Girlfriend
        </p>
        
        <h1 className="font-script text-6xl md:text-8xl lg:text-9xl text-white mb-6 drop-shadow-2xl animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
          Happy Valentine's Day
        </h1>
        
        <div className="flex justify-center gap-4 mb-8 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
          <Heart className="w-10 h-10 text-rose-400 fill-rose-400 animate-pulse-heart" />
          <Heart className="w-12 h-12 text-rose-500 fill-rose-500 animate-pulse-heart" style={{ animationDelay: '0.2s' }} />
          <Heart className="w-10 h-10 text-rose-400 fill-rose-400 animate-pulse-heart" style={{ animationDelay: '0.4s' }} />
        </div>
        
        <p className="font-display text-lg md:text-xl text-rose-100 max-w-2xl mx-auto mb-10 animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
          Every moment with you is a gift, every smile a treasure. 
          Today, I want to remind you just how much you mean to me.
        </p>
        
        <Button 
          onClick={scrollToLetter}
          className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-6 rounded-full text-lg font-display btn-glow animate-fade-in-up"
          style={{ animationDelay: '1s' }}
        >
          Open My Heart <ArrowDown className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </section>
  )
}

// Love Letter Section
function LoveLetterSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.3 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section 
      id="love-letter" 
      ref={sectionRef}
      className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-rose-50 to-pink-50"
    >
      <div className={`max-w-3xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="text-center mb-12">
          <Heart className="w-12 h-12 text-rose-500 mx-auto mb-4 animate-float" />
          <h2 className="font-script text-5xl md:text-6xl gradient-text mb-4">My Love Letter to You</h2>
        </div>
        
        <div className="love-letter rounded-3xl p-8 md:p-12 relative">
          {/* Decorative corners */}
          <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-rose-300 rounded-tl-lg" />
          <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-rose-300 rounded-tr-lg" />
          <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-rose-300 rounded-bl-lg" />
          <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-rose-300 rounded-br-lg" />
          
          <div className="font-script text-3xl text-rose-600 mb-6">My Dearest Love,</div>
          
          <div className="font-display text-lg text-gray-700 leading-relaxed space-y-4">
            <p>
              As I sit down to write this letter, my heart overflows with love for you. 
              Words seem insufficient to express the depth of my feelings, but I'll try 
              my best to let you know what you mean to me.
            </p>
            <p>
              From the moment you entered my life, everything changed. The world became 
              brighter, colors more vivid, and every day became an adventure I wanted to 
              share with you. Your smile is the first thing I think of in the morning 
              and the last thing on my mind at night.
            </p>
            <p>
              I love the way you laugh, the way your eyes light up when you're excited, 
              and the way you care so deeply about the people you love. Your kindness, 
              your strength, and your beautiful spirit inspire me every single day.
            </p>
            <p>
              Thank you for being my partner, my best friend, and my greatest love. 
              I promise to cherish you, support you, and love you more with each passing day.
            </p>
            <p className="font-script text-2xl text-rose-600 mt-8">
              Forever Yours,<br />
              With All My Love
            </p>
          </div>
          
          <div className="flex justify-center mt-8">
            <Heart className="w-8 h-8 text-rose-400 fill-rose-400 animate-pulse-heart" />
          </div>
        </div>
      </div>
    </section>
  )
}

// Reasons I Love You Section
function ReasonsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const reasons = [
    { icon: <Heart className="w-6 h-6" />, text: "Your beautiful smile that lights up my world" },
    { icon: <Star className="w-6 h-6" />, text: "The way you make every moment special" },
    { icon: <Music className="w-6 h-6" />, text: "Your laugh that sounds like music to my ears" },
    { icon: <Sparkles className="w-6 h-6" />, text: "Your kindness that touches everyone around you" },
    { icon: <Gift className="w-6 h-6" />, text: "How you always know how to make me feel better" },
    { icon: <Heart className="w-6 h-6" />, text: "The way you love me for who I am" },
  ]

  return (
    <section 
      ref={sectionRef}
      className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-pink-50 to-rose-100"
    >
      <div className={`max-w-5xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="text-center mb-16">
          <h2 className="font-script text-5xl md:text-6xl gradient-text mb-4">Reasons Why I Love You</h2>
          <p className="font-display text-lg text-gray-600">There are infinite reasons, but here are just a few...</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="glass rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 bg-rose-500 rounded-full flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform">
                {reason.icon}
              </div>
              <p className="font-display text-gray-700">{reason.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Photo Gallery Section
function GallerySection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const photos = [
    { src: '/couple-sunset.jpg', alt: 'Together Forever', caption: 'Every sunset is beautiful with you' },
    { src: '/roses.jpg', alt: 'Beautiful Roses', caption: 'You are as beautiful as these roses' },
    { src: '/dinner.jpg', alt: 'Romantic Dinner', caption: 'Every meal is a date with you' },
    { src: '/chocolates.jpg', alt: 'Sweet Chocolates', caption: 'You make life sweeter' },
    { src: '/hugging.jpg', alt: 'Warm Hugs', caption: 'Your hugs are my favorite place' },
  ]

  return (
    <section 
      ref={sectionRef}
      className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-rose-100 to-pink-50"
    >
      <div className={`max-w-6xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="text-center mb-16">
          <h2 className="font-script text-5xl md:text-6xl gradient-text mb-4">Our Beautiful Moments</h2>
          <p className="font-display text-lg text-gray-600">Memories that make my heart smile</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg photo-hover"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <img
                src={photo.src}
                alt={photo.alt}
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-rose-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="font-script text-xl text-white">{photo.caption}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Final Message Section
function FinalSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)
  const [showHearts, setShowHearts] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.3 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleLoveClick = () => {
    setShowHearts(true)
    setTimeout(() => setShowHearts(false), 3000)
  }

  return (
    <section 
      ref={sectionRef}
      className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-pink-50 to-rose-200"
    >
      <div className={`max-w-3xl mx-auto text-center transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <Heart className="w-16 h-16 text-rose-500 mx-auto mb-6 animate-pulse-heart" />
        
        <h2 className="font-script text-5xl md:text-7xl gradient-text mb-8">
          I Love You
        </h2>
        
        <p className="font-display text-xl text-gray-700 mb-10 leading-relaxed">
          Thank you for being the most amazing girlfriend in the world. 
          You make every day feel like Valentine's Day. 
          I am so grateful to have you in my life.
        </p>
        
        <div className="mb-10">
          <Button
            onClick={handleLoveClick}
            className="bg-rose-500 hover:bg-rose-600 text-white px-10 py-6 rounded-full text-xl font-script btn-glow relative overflow-hidden"
          >
            <span className="relative z-10">Click for a Surprise!</span>
            {showHearts && (
              <div className="absolute inset-0 flex items-center justify-center">
                {Array.from({ length: 8 }).map((_, i) => (
                  <Heart
                    key={i}
                    className="absolute w-6 h-6 text-white animate-float"
                    style={{
                      left: `${20 + i * 10}%`,
                      animationDelay: `${i * 0.1}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </Button>
        </div>
        
        <div className="glass-dark rounded-3xl p-8 inline-block">
          <p className="font-script text-2xl text-white mb-2">Forever & Always</p>
          <p className="font-display text-rose-200">Your Loving Boyfriend</p>
        </div>
        
        <div className="flex justify-center gap-3 mt-10">
          {Array.from({ length: 5 }).map((_, i) => (
            <Heart
              key={i}
              className="w-6 h-6 text-rose-400 fill-rose-400 animate-float"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

// Footer
function Footer() {
  return (
    <footer className="bg-rose-900 text-rose-200 py-8 px-4 text-center">
      <p className="font-script text-xl mb-2">Made with</p>
      <div className="flex justify-center gap-2 mb-4">
        <Heart className="w-5 h-5 text-rose-400 fill-rose-400 animate-pulse-heart" />
        <Heart className="w-6 h-6 text-rose-500 fill-rose-500 animate-pulse-heart" style={{ animationDelay: '0.1s' }} />
        <Heart className="w-5 h-5 text-rose-400 fill-rose-400 animate-pulse-heart" style={{ animationDelay: '0.2s' }} />
      </div>
      <p className="font-display text-sm">Happy Valentine's Day 2026</p>
    </footer>
  )
}

// Main App
function App() {
  return (
    <div className="min-h-screen bg-rose-50">
      <FloatingHearts />
      <HeroSection />
      <LoveLetterSection />
      <ReasonsSection />
      <GallerySection />
      <FinalSection />
      <Footer />
    </div>
  )
}

export default App
